package interfaceStyle;

import org.junit.Assert;
import org.junit.Test;

/**
 * Project: annotation
 * User: tjlee
 * Date: 2017. 7. 17.
 * Time: PM 4:13
 */
public class DoSomethingTest {

    private String interfaceResult;

    private void setInterfaceResult(String result) {
        this.interfaceResult = result;
    }

    @Test
    public void test1() {
        final String expected = "helloWorld";
        DoSomething.getInstance().setJob(() -> setInterfaceResult(expected));
        DoSomething.getInstance().doJob();
        Assert.assertEquals(expected, interfaceResult);
    }
}