package annotationStyle;

import annotationStyle.DoSomething.Job;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;

/**
 * Project: annotation
 * User: tjlee
 * Date: 2017. 7. 17.
 * Time: PM 5:33
 */
public class DoSomethingTest {

    private String interfaceResult;
    private final String expected = "helloWorld";

    private void setInterfaceResult(String result) {
        this.interfaceResult = result;
    }

    @After
    public void after() {
        interfaceResult = null;
    }

    public class TestJob {
        @Job
        public void job() {
            setInterfaceResult(expected);
        }
    }

    @Test
    public void test1() {
        DoSomething.getInstance().setJob(TestJob.class, new TestJob());
        DoSomething.getInstance().doJob();
        Assert.assertEquals(expected, interfaceResult);
    }

    @Job
    void job() {
        setInterfaceResult(expected);
    }

    @Test
    public void test2() {
        DoSomething.getInstance().setJob(DoSomethingTest.class, this);
        DoSomething.getInstance().doJob();
        Assert.assertEquals(expected, interfaceResult);
    }
}