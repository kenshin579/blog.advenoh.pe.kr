package test;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

public class CustomAnnotation2 {

    @Target(ElementType.FIELD)
    @Retention(RetentionPolicy.RUNTIME)
    public @interface ObjectId {
    }

    public static void main(String[] args) {

    }
}


class SkillSpec {
    @CustomAnnotation2.ObjectId
    private String oId;
    private String name;
}

