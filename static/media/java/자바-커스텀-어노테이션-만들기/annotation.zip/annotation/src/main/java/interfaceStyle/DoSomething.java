package interfaceStyle;

/**
 * Project: annotation
 * User: tjlee
 * Date: 2017. 7. 17.
 * Time: PM 5:07
 */
public class DoSomething {
    private static DoSomething ourInstance = new DoSomething();

    public static DoSomething getInstance() {
        return ourInstance;
    }

    private DoSomething() {
    }

    private Job job;

    interface Job {
        void run();
    }

    void setJob(Job job) {
        this.job = job;
    }

    void doJob() {
        if (null != this.job) {
            job.run();
        }
    }
}
