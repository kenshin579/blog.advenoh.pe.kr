package test;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Method;

public class CustomAnnotation {
    //Creating annotation
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    @interface MyAnnotation {
        int value();
    }

    public static void main(String args[]) throws Exception {
        //Accessing annotation
        Hello h = new Hello();
        Method m = h.getClass().getMethod("sayHello");

        MyAnnotation manno = m.getAnnotation(MyAnnotation.class);
        System.out.println("value is: " + manno.value());
    }
}

//Applying annotation
class Hello {
    @CustomAnnotation.MyAnnotation(value = 10)
    public void sayHello() {
        System.out.println("hello annotation");
    }
}
