package annotationStyle;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Project: annotation
 * User: tjlee
 * Date: 2017. 7. 17.
 * Time: PM 4:02
 */
class DoSomething {
    private static DoSomething ourInstance = new DoSomething();
    private Method method;
    private Object jobClassInstance;

    static DoSomething getInstance() {
        return ourInstance;
    }

    private DoSomething() {
    }

    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.RUNTIME)
    @interface Job {
    }

    void setJob(Class clazz, Object obj) {
        for (Method method : clazz.getDeclaredMethods()) {
            if (method.isAnnotationPresent(Job.class)) {
                this.method = method;
                this.jobClassInstance = obj;
                break;
            }
        }
    }

    void doJob() {
        if (null != this.method) {
            try {
                this.method.invoke(jobClassInstance);
            } catch (IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
            }
        }
    }

}
