package test;

import java.lang.reflect.Field;

public class ObjectIdAnnotator {
    public static String getObjectIdValue(Object entity) throws IllegalAccessException {
        Class<? extends Object> clazz = entity.getClass();

        for (Field field : clazz.getDeclaredFields()) {
            if (field.getAnnotation(CustomAnnotation2.ObjectId.class) != null) {
                field.setAccessible(true);
                Object value = field.get(entity);
                if (value == null) {
                    return null;
                } else {
                    return value.toString();
                }
            }
        }
        throw new RuntimeException("No annotated id field.");
    }
}
