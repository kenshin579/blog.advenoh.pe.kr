package myAnnotation.classAnnotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

public class ClassAnnotation {
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.TYPE)
    public @interface MyAnnotation {
        public String name();

        public String value();
    }

    public static void main(String[] args) {
        Class aClass = TheClass.class;
        Annotation annotation = aClass.getAnnotation(MyAnnotation.class);

        if(annotation instanceof MyAnnotation){
            MyAnnotation myAnnotation = (MyAnnotation) annotation;
            System.out.println("name: " + myAnnotation.name());
            System.out.println("value: " + myAnnotation.value());
        }
    }
}

@ClassAnnotation.MyAnnotation(name = "someName", value = "Hello World")
class TheClass {
}